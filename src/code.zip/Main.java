import UI.LoginClient;
import UI.RegisterClient;
import javafx.stage.Stage;

public class Main {

    public static void main(String[] args) {
        // 在 JavaFX 主线程中启动应用程序
        javafx.application.Platform.startup(() -> {
            LoginClient loginClient = new LoginClient();
            // 设置回调函数
            loginClient.setButtonClickListener(message -> {
                // 处理按钮点击后返回的消息
                String loginAccount = message[0];    //account
                String loginPassword = message[1];   //password
                System.out.println("account: " +loginAccount);
                System.out.println("password: "+loginPassword);
                // 在这里执行您想要的操作
            });
            loginClient.setRegisterClickListener(flag -> {
                //打开注册界面
                if(flag){
                    RegisterClient registerClient = new RegisterClient();
                    registerClient.start(new Stage());
                    registerClient.setButtonClickListener(messages -> {
                        String registerName = messages[0];
                        String registerPassword = messages[1];
                        String registerAgainPassword = messages[2];
                        System.out.println("registerName: "+registerName);
                        System.out.println("registerPassword: "+registerPassword);
                        System.out.println("registerAgainPassword: "+registerAgainPassword);
                    });
                }
            });
            // 启动 JavaFX 应用程序
            loginClient.start(new Stage());
        });
        System.out.println("进行其他初始化——————");
    }
}