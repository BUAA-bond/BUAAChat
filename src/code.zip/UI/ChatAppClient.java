package UI;

import javafx.application.Application;
import javafx.stage.Stage;
public class ChatAppClient extends Application {

    @Override
    public void start(Stage stage) throws Exception {

    }
}
