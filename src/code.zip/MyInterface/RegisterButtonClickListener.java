package MyInterface;

public interface RegisterButtonClickListener {
    void onClick(boolean flag);
}
