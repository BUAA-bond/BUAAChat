package MyInterface;

public interface RegisterButtonListener {
    void onLoginButtonClick(String[] message);
}
