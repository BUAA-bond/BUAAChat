package MyInterface;

// 在一个公共的包下创建接口
public interface LoginButtonClickListener {
    void onLoginButtonClick(String[] messages);
}
